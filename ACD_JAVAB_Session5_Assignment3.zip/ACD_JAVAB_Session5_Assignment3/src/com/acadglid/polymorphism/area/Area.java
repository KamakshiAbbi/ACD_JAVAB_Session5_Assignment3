//Session4_Assignment5 : 14.5.2016
//Author: Kamakshi Abbi
package com.acadglid.polymorphism.area;
import java.util.Scanner;
public class Area {
		int area;
		//constructor overloading
		public Area(int length, int breadth) {
			area = length*breadth;
			System.out.println("The area of rectangle is " + area);
	
		}
		public Area(int side){
			area = side*side;
			System.out.println("The area of square is " + area);
		
		}
		public static void main(String[] args) {
			int l,b,s;
			Scanner input = new Scanner(System.in);
			System.out.println("Enter the length of rectangle");
			l = input.nextInt();
			System.out.println("Enter the breadth of rectangle");
			b = input.nextInt();
			Area a1 = new Area(l, b);
			System.out.println("Enter the side of square");
			s = input.nextInt();
			Area a2 = new Area(s);
			input.close();
			
		}

}
